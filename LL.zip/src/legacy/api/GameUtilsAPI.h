#pragma once
#include "api/APIHelp.h"

extern ClassDefine<void> TextClassBuilder;
