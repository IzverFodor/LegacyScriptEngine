#pragma once
#include <string>

bool ProcessDebugEngine(const std::string& cmd);
void RegisterDebugCommand();
