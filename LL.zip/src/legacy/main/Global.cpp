#include "main/Global.h"

// 全局变量
bool isCmdRegisterEnabled = false;