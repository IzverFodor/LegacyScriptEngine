#pragma once

#include "PluginManager.h"

namespace lse {

auto migratePlugins(const PluginManager& pluginManager) -> void;

} // namespace lse
