#pragma once

namespace lse {

struct Config {
    int  version        = 1;
    bool migratePlugins = true;
};

} // namespace lse
