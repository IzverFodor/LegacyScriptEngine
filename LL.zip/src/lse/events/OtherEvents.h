#pragma once

namespace lse::events::other {
void ScoreChangedEvent();
}