// This file will make your plugin use LeviLamina's memory operators by default.
// This improves the memory management of your plugin and is recommended to use.

#define LL_MEMORY_OPERATORS

#include <ll/api/memory/MemoryOperators.h>
