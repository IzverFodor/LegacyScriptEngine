# FAQ

## What is the purpose of this project?

The purpose of this project is to run LLSE plugins on LeviLamina.

## Does this project support all LLSE plugins?

Almost all LLSE plugins are supported, but some plugins may not work properly due to the differences in event triggering timing and other reasons.

## How long will this project be maintained?

This project will be maintained as long as we maintainers have the ability and time to maintain it.
